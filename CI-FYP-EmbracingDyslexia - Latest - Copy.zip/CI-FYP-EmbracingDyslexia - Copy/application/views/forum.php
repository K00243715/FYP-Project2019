<?php
$this->load->view('header'); 
$this->load->helper('url'); 
$base = base_url() . index_page();
$img_base = base_url();
$cssbase = base_url();
$user = $this->session->userdata('user');
?>




<!--PAGE LOGO & TITLE-->
<!--SECTION 01-->
  <section class="titles">
    <h1>Have Your Say!</h1>
    <h2>Leave your advice & experience in the community forum. </h2>
    <p>Your never know who will benefit!</p>
  </section>
       
       
<!--SECTION 02-->
  <section class="container-boxes">
    <div class="box">

      <div class="icon">
        <a href=""><i class="fas fa-fire"></i></a>
      </div>

      <div class="text">
        <a href="">
          <h3>Add forum through codeigniter</h3>
            <p>CI FORUM</p>
            <p>Message for users?</p>
        </a>
      </div> 
      </div>
      
         <div class="box">

      <div class="icon">
        <a href=""><i class="fas fa-fire"></i></a>
      </div>

      <div class="text">
        <a href="<?php echo "$base/User/forum"?>">
            <h3>CI FORUM</h3>
            <p><img src="<?php echo $img_base . "assets/images/FORUM.PNG"?>"></p>
        </a>
      </div>

    </div>
       </section>


<?php
$this->load->view('footer'); 
?>