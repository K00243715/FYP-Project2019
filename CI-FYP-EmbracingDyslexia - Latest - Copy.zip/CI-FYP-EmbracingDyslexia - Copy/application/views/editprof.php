<?php
$this->load->view('header'); 
$this->load->helper('url'); 
$base = base_url() . index_page();
$img_base = base_url();
$cssbase = base_url();
$user = $this->session->userdata('user');

?>

   
       
<!--PAGE LOGO & TITLE-->
<!--SECTION 01-->
  <section class="titles">
    <h1>Edit Your Profile</h1>
    <h2>Update you profile</h2>
  </section>
    <br><br><br><br><br><br><br><br><br>
    <br><br><br><br><br><br><br><br><br>   
       
<!--SECTION 02-->
  <section class="container-boxes">
    <div class="box">

      <div class="icon">
      </div>

      <div class="text">
          <a href="<?php echo "$base/User/profile"?>">
          <h3>Return to your Profile</h3>
            <p>Finished editing your personal profile?</p>
        </a>
      </div> 
      </div>
 
      
      
<!--editPROFILE-->      
      <div class="container">
  <div id="sc-edprofile">
  <h1>Edit Profile Form</h1>
  <div class="sc-container">
    <input type="text" placeholder="Username" />
    <input type="text" placeholder="Email Address" />
    <input type="password" placeholder="Password" />
    <input type="text" placeholder="First Name" />
    <input type="text" placeholder="Last Name" />
    <textarea placeholder="Bio"></textarea>
    <select>
      <option value="">Male</option>
      <option value="">Female</option>
    </select>
    <input type="text" placeholder="Twitter Profile URL" />
    <input type="text" placeholder="LinkedIn Profile URL" />
    <input type="submit" value="Register" />
  </div>
</div>
      </div>
       </section>
    <br><br><br><br><br><br><br><br><br>
    <br><br><br><br><br><br> <br><br><br>

 
<?php
$this->load->view('footer'); 
?>