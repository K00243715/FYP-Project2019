<?php
$this->load->view('header'); 
$this->load->helper('url'); 
$base = base_url() . index_page();
$img_base = base_url();
$n = $this->session->userdata('AllNoticeData');

if(!$n==null){ ?>
	<table border="1" align="center">
		<th width="130">Image</th>
        <th width="130">Description</th>
        <th width="130">area</th>
        <?php foreach ($n as $notice){
			echo "<tr>";
			    echo "<td width=\"130\"> <a href=\"$base/Notice/getDrillDownNoticeAndUser/". 
					$notice['noticeId'] . "\"><img src=\"$img_base/assets/images/thumbs/". 
					$notice['largeImage']. "\" /> </a> </td>";
				echo "<td width=\"130\">" . $notice['shortDescription'] . "</td>";
				echo "<td width=\"130\">" . $notice['area'] . "</td>";
     	    echo "</tr>";
		}?>
    </table>
<?php } ?>                

<?php
$this->load->view('footer'); 
?>