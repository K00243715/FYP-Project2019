<?php
$this->load->view('header'); 
$this->load->helper('url'); 
$base = base_url() . index_page();
$img_base = base_url();
?>

       

<!--SECTION 01-->
  <section class="titles">
    <h1>Your Profile</h1>
    <h2>These free online games can relax you, get your brain working, or just simply give you a chance to have some fun and take a break from the day-to-day.</h2>
  </section>
       
       
<!--SECTION 02-->
  <section class="container-boxes">
    <div class="box">

      <div class="icon">
      </div>

      <div class="text">
        <a href="<?php echo "$base/User/editprof"?>">
          <h3>Create a Profile</h3>
            <p>It’s free to sign up and access more features. Connect with friends and the community around you on Embracing Dyslexia.</p>
        </a>
      </div> 
      </div>
 
      
      
<!--PROFILE-->      
      <div class="container">
  <div class="browser">
      
<p>Return to Accessibility <a href="<?php echo "$base/User/accessibility"?>">menu</a>?</p>


    <div class="card-info">
      <div class="dribble-title">DRIBBBLE</div>
      <div class="author-info">
        <div class="author-name">
          Albus Dumbledore
        </div>
        <a href="<?php echo "$base/User/editprof"?>"><div class="author-title">Edit Profile</div> </a>
      </div>
      <div class="card-end"> </div>
    </div>
    <div class="portfolio">

      <div class="menu-filter">
        <div class="menu">ME</div>
        <div class="portfolio-items">
            <p>I am a primary school teacher, interested in sharing ideas about dyslexia and learning more from parents and my school community.</p>
      </div>
        <div class="menu">JOB</div>
        <div class="menu">INTERESTS</div>
       
      </div>
    </div>
    
    <div class="hover-me">Access more features by signing up!</div>
    <div class="circle-set">
      <div class="circle circle-pink"> </div>
      <div class="circle circle-orange"> </div>
      <div class="circle circle-green"> </div>
    </div>
    <div class="tooltip right">
      <div class="tooltip-inner"></div>
    </div>
  </div>
  <br>
      </div>
       </section>
    



<?php
$this->load->view('footer'); 
?>