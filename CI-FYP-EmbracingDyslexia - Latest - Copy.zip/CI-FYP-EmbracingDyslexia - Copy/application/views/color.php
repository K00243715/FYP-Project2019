<?php
$this->load->view('header'); 
$this->load->helper('url'); 
$base = base_url() . index_page();
$img_base = base_url();
$cssbase = base_url();
$user = $this->session->userdata('user');

?>




<!--PAGE LOGO & TITLE-->
<!--SECTION 01-->
  <section class="titles">
    <h1>COLOR SAFE</h1>
    <h2>Empowering you to design and access your website with beautiful and accessible color palettes.</h2>
    <p>Return to Accessibility <a href="<?php echo "$base/User/accessibility"?>">menu</a>?</p>
  </section>
       
       
<!--SECTION 02-->
  <section class="container-boxes">
    <div class="box">

      <div class="icon">
        <a href=""><i class="fas fa-fire"></i></a>
      </div>

      <div class="text">
        <a href="">
          <h3>Color Safe</h3>
            <p>Enter a background color, and determine the personal styling of your text. </p>
            <p>Accessible text colors are generated with WCAG Guidelines recommend contrast ratio of 4.5 for small text or 3 for large text which is 24px or 18px bold.</p>
        </a>
      </div> 
      </div>
      
         <div class="box">

      <div class="icon">
        <a href="http://colorsafe.co/"><i class="fas fa-fire"></i></a>
      </div>

      <div class="text">
        <a href="http://colorsafe.co/">
            <h3>Take Me There!</h3>
            <p><img src="<?php echo $cssbase . "/assets/images/acc1.PNG"?>" alt="colorsafe"></p>
        </a>
      </div>

    </div>
       </section>



<?php
$this->load->view('footer'); 
?>