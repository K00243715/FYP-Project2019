<?php 
$img_base = base_url();
$base = base_url() . index_page();
$cssbase = base_url();
?>


</br></br>
</div>
<!--Footer-->
        <footer>
        &copy; Copyright 2019 | AMI
            <!--SOCIAL MEDIA LINKS-->
                    <a href="https://www.flickr.com/photos/dyslexiaireland/"><img src="<?php echo $img_base . "assets/images/flickerIcon.PNG"?>" alt="smedia"></a>
                
                    <a href="https://www.facebook.com/DyslexiaIreland/"><img src="<?php echo $img_base . "assets/images/FBIcon.PNG"?>" alt="smedia"></a>
                
                    <a href="https://www.instagram.com/madebydyslexia/?hl=en"><img src="<?php echo $img_base . "assets/images/InstaIcon.PNG"?>" alt="smedia"></a>
                
                    <a href="https://en.wikipedia.org/wiki/Dyslexia"><img src="<?php echo $img_base . "assets/images/WikiIcon.PNG"?>" alt="smedia"></a>
                
                    <a href="https://twitter.com/dyslexiaireland?lang=en"><img src="<?php echo $img_base . "assets/images/TwiiterIcon.PNG"?>" alt="smedia"></a>
            </footer>
</body>
</html>