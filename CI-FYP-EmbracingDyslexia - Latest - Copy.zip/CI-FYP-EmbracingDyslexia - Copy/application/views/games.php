<?php
$this->load->view('header'); 
$this->load->helper('url'); 
$base = base_url() . index_page();
$img_base = base_url();
$cssbase = base_url();
$user = $this->session->userdata('user');
?>


       
       
<!--PAGE LOGO & TITLE-->
<!--SECTION 01-->
  <section class="titles">
    <h1>Play A Game!</h1>
    <h2>Challenge your mind with a brain game for memory, math, vocabulary and more. </h2>
    <p>Food For The Mind</p>
  </section>
       
       
<!--SECTION 02-->
  <section class="container-boxes">
    <div class="box">

      <div class="icon">
        <a href=""><i class="fas fa-fire"></i></a>
      </div>

      <div class="text">
        <a href="">
          <h3>Add GAME/QUIZ through codeigniter</h3>
            <p>GAME / QUIZ</p>
            <p>Message for users?</p>
        </a>
      </div> 
      </div>
      
         <div class="box">

      <div class="icon">
        <a href=""><i class="fas fa-fire"></i></a>
      </div>

      <div class="text">
        <a href="">
            <h3>GAME QUIZ</h3>
            <p><img src="<?php echo $img_base . "assets/images/QUIZ.PNG"?>"></p>
        </a>
      </div>

    </div>
       </section>
    
    <!--SECTION 03-->
      <section class="container-boxes">
    <div class="box">

      <div class="icon">
        <a href=""><i class="fas fa-fire"></i></a>
      </div>

      <div class="text">
        <a href="">
          <h3>GAME 1</h3>
            <p>  <a href="https://codepen.io/katieyang/full/MmXyoj/" target="_blank"><img src="https://s3.amazonaws.com/profilepagepics/portfolio+pic+8.png" class="projectsample"></a> </p>
        </a>
      </div> 
      </div>
      
         <div class="box">

      <div class="icon">
        <a href=""><i class="fas fa-fire"></i></a>
      </div>

      <div class="text">
        <a href="games.html">
            <h3>GAME 2</h3>
            <p> <a href="https://codepen.io/katieyang/full/zzWLYv/" target="_blank"><img src="https://s3.amazonaws.com/profilepagepics/portfolio+pic+7.png" class="projectsample"></a></p>
        </a>
      </div>

    </div>
       </section>
    




<?php
$this->load->view('footer'); 
?>