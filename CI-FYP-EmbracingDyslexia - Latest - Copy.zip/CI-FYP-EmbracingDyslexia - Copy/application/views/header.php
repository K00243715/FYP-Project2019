<?php 
$this->load->helper('url'); 
$cssbase = base_url();
$img_base = base_url();
$base = base_url() . index_page();
$user = $this->session->userdata('user');
?>

<!DOCTYPE>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <title>FYP - Embracing Dyslexia - K00243715 - Ashley McInerney</title>
    
    <!--reference to CSS file-->
    <link href="<?php echo $cssbase . "/assets/css/styles.css"?>" rel="stylesheet" type="text/css" media="all" />
    
            
    <!--tab favicon-->
    <link href="$user = $this->session->userdata('user');fav2.PNG"?>
        
    <!--W3Schools Search Icon Info-->
    <meta name="viewport" content="width=device-width, initial-scale=1">
</head>
    
    
    
<!--BODY-->
<body>

<!--HEADER--> 
  <header>
      
    <div>
        <a href="<?php echo "$base/User/home"?>">   
        <img src="<?php echo $img_base . "assets/images/logo3.PNG"?>" alt="logoFavicon">
        <link rel="icon"></a>
        
      <i class="fas fa-atom"></i>
    </div>
      
<!--NAV BAR-->    
    <nav>
      <ul>
        <li><a href="<?php echo "$base/User/home"?>">Home</a></li>
        <li><a href="<?php echo "$base/User/profile"?>">Login</a></li>
        <li><a href="<?php echo "$base/User/accessibility"?>">Accessibility</a></li>
          
        <li><a href="<?php echo "$base/User/games"?>">Games</a></li>
        <li><a href="<?php echo "$base/User/forum"?>">Forum</a></li>
        <li><a href="<?php echo "$base/User/contact"?>">Contact</a></li>

      </ul>
    </nav>
      
  </header>
    
    