<?php
$this->load->view('header'); 
$this->load->helper('url'); 
$base = base_url() . index_page();
$img_base = base_url();
$cssbase = base_url();
$user = $this->session->userdata('user');
?>


       
       
<!--PAGE LOGO & TITLE-->
<!--SECTION 01-->
  <section class="titles">
    <h1>Play A Game!</h1>
    <h2>Challenge your mind with a brain game for memory, math, vocabulary and more. </h2>
    <p>Food For The Mind</p>
  </section>
       
       
<!--SECTION 02-->
  <section class="container-boxes">
    <div class="box">

      <div class="icon">
        <a href=""><i class="fas fa-fire"></i></a>
      </div>

      <div class="text">
        <a href="">
          <h3>PLay a game of your choice.</h3>
            <p>Leave game suggestions for future users in the community forum.</p>
        </a>
      </div> 
      </div>
      
         <div class="box">

      <div class="icon">
        <a href=""><i class="fas fa-fire"></i></a>
      </div>

      <div class="text">
        <a href="<?php echo "$base/NewController/doQuiz";?>">
            <h3>Challenge yourself</h3>
            <p><img src="<?php echo $img_base . "assets/images/QUIZ.PNG"?>"></p>
        </a>
      </div>

    </div>
      
        <div class="box">

      <div class="icon">
        <a href=""><i class="fas fa-fire"></i></a>
      </div>

      <div class="text">
        <a href="">
          <h3>FILL ME IN</h3>
            <p>fILL ME IN</p>
        </a>
      </div> 
      </div>
       </section>
    
    <!--SECTION 03-->
      <section class="container-boxes">
    <div class="box">

      <div class="icon">
        <a href=""><i class="fas fa-fire"></i></a>
      </div>

      <div class="text">
        <a href="">
            <h3>Game 01</h3>
            <p>  <a href="https://codepen.io/katieyang/full/MmXyoj/" target="_blank"><img src="https://s3.amazonaws.com/profilepagepics/portfolio+pic+8.png" class="projectsample"></a> </p>
        </a>
      </div> 
      </div>
      
         <div class="box">

      <div class="icon">
        <a href=""><i class="fas fa-fire"></i></a>
      </div>

      <div class="text">
        <a href="games.html">
            <h3>GAME 02</h3>
            <p> <a href="https://codepen.io/katieyang/full/zzWLYv/" target="_blank"><img src="https://s3.amazonaws.com/profilepagepics/portfolio+pic+7.png" class="projectsample"></a></p>
        </a>
      </div>

    </div>
       </section>





    




<?php
$this->load->view('footer'); 
?>