<?php
$this->load->view('header'); 
$this->load->helper('url');
$base = base_url() . index_page();

?>
	<div class="center-text">
	<h1>Quiz Results</h1>
	<p><?php echo $output?></p>
	</div>

<?php
$this->load->view('footer'); 
?>