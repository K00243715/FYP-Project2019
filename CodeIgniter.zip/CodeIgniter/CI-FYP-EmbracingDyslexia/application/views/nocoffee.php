<?php
$this->load->view('header'); 
$this->load->helper('url'); 
$base = base_url() . index_page();
$img_base = base_url();
?>




<!--PAGE LOGO & TITLE-->
<!--SECTION 01-->
  <section class="titles">
    <h1>NoCoffee</h1>
    <h2>Vision Stimulator - This extension can be helpful for understanding the problems faced by people with slight to extreme vision problems</h2>
      <p>Return to Accessibility <a href="<?php echo "$base/User/accessibility"?>">menu</a>?</p>
  </section>
       
       
<!--SECTION 02-->
  <section class="container-boxes">
    <div class="box">

      <div class="icon">
        <a href=""><i class="fas fa-fire"></i></a>
      </div>

      <div class="text">
        <a href="">
          <h3>NoCoffee</h3>
            <p>Low acuity, low contrast sensitivity, colorblindness, visual snow, glare & cataracts are some of the issues facing people with visual ailments.</p>
            <p>NoCoffee is a vision simulator to assist those with vision problems.</p>
        </a>
      </div> 
      </div>
      <div class="box">

      <div class="icon">
        <a href=""><i class="fas fa-fire"></i></a>
      </div>

      <div class="text">
        <a href="https://chrome.google.com/webstore/detail/nocoffee/jjeeggmbnhckmgdhmgdckeigabjfbddl">
          <h3>NoCoffee</h3>
          <p><img src="<?php echo $img_base . "assets/images/nocoffee.PNG"?>"></p>
        </a>
      </div> 
      </div>
       </section>




<?php
$this->load->view('footer'); 
?>