<?php
$this->load->view('header'); 
$this->load->helper('url');
$base = base_url() . index_page();
$img_base = base_url();
?>
	
	<div class="jsquizbody">
		<h1 class="center-text">JavaScript Trivia Quiz</h1>
		<p class="jsquizp_style">Asking question <span id="NumberAsked">1</span> of 5 with <span id="NumberCorrect">0</span> answers correct</p>

		<p class="jsquizp_style"><span id="TriviaQuestion">???</span></p>

		<p class="jsquizp_style">	
			<input id="RadioTrue"  type="radio" value="true"  name="answer" checked="checked" /> True
			<input id="RadioFalse" type="radio" value="false" name="answer" /> False</p>

		<p><input id="ButtonContinue" onclick="checkAnswer();" type="button" value="Start/Continue" class="button_style" /></p>
	</div>
<?php
$this->load->view('footer'); 
?>