<?php
$this->load->view('header'); 
$this->load->helper('url'); 
$base = base_url() . index_page();
$img_base = base_url();
$cssbase = base_url();
$user = $this->session->userdata('user');
?>




 <!--PAGE LOGO & TITLE-->
<!--SECTION 01-->
  <section class="titles">
    <h1>Colour Contrast Analyzer</h1>
    <h2>You can choose to analyze a portion of a web page, the entire visible contents of a tab, or an entire web page.</h2>
    <p>Return to Accessibility <a href="<?php echo "$base/User/accessibility"?>">menu</a>?</p>
  </section>
       
       
<!--SECTION 02-->
  <section class="container-boxes">
    <div class="box">

      <div class="icon">
        <a href=""><i class="fas fa-fire"></i></a>
      </div>

      <div class="text">
        <a href="">
            <h3>Without Contrast Analyzer</h3>
            <p><img src="<?php echo $img_base . "assets/images/cont1.PNG"?>"></p>
        </a>
      </div>

    </div>
      
      
        <div class="box">

      <div class="icon">
        <a href=""><i class="fas fa-fire"></i></a>
      </div>

      <div class="text">
        <a href="">
          <h3>Colour Contrast Analyzer</h3>
            <p>This extension allows you to analyze text color contrast problems on a webpage according to the WCAG 2 text color contrast requirements.</p>
            <p>Press on the picture on the right to add the extension to your Chrome browser. </p>
        </a>
      </div> 
      </div>
      
         <div class="box">

      <div class="icon">
        <a href="https://chrome.google.com/webstore/detail/color-contrast-analyzer/dagdlcijhfbmgkjokkjicnnfimlebcll"><i class="fas fa-fire"></i></a>
      </div>

      <div class="text">
        <a href="https://chrome.google.com/webstore/detail/color-contrast-analyzer/dagdlcijhfbmgkjokkjicnnfimlebcll">
            <h3>With Contrast Analyzer</h3>
            <p><img src="<?php echo $img_base . "assets/images/cont2.PNG"?>"></p>
        </a>
      </div>

    </div>
       </section>




<?php
$this->load->view('footer'); 
?>