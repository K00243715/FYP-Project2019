<?php 

class Quiz extends CI_Controller {

	public function __construct(){
		parent::__construct();
		$this->load->model('User_Model');
		$this->load->library('session');
		$this->load->model('quiz_model');
	}

	public function doQuizStart($qIn){
			session_start();
			if($qIn){
				$question = preg_replace('/[^0-9]/', "", $qIn);
				$next = $question + 1;
				$prev = $question - 1;
				if(!isset($_SESSION['qid_array']) && $question != 1){
				$data['msg'] = "Sorry! No cheating.";
				$this->load->view("quizMainPage", $data);
			}
			if(isset($_SESSION['qid_array']) && in_array($question, $_SESSION['qid_array'])){
				$data['msg']  = "Sorry, Cheating is not allowed. You will now have to start over.";
				unset($_SESSION['answer_array']);
				unset($_SESSION['qid_array']);
				session_destroy();
				$this->load->view("quizMainPage", $data);

			}
			if(isset($_SESSION['lastQuestion']) && $_SESSION['lastQuestion'] != $prev){
				$data['msg'] =  "Sorry, Cheating is not allowed. You will now have to start over.";
				unset($_SESSION['answer_array']);
				unset($_SESSION['qid_array']);
				session_destroy();
				$this->load->view("quizMainPage", $data);
			
			}
		
			if(!isset($data['msg'])){
				$this->getQuestions($question);
			}
		}
		
	}
	
	public function getQuestions($qIn){
		
		$arrCount = "";
		$question = preg_replace('/[^0-9]/', "", $qIn);
		$output = "";
		$answers = "";
		$q = "";
		
		$sql = $this->quiz_model->getAllQuizID();
		$numQuestions = $sql->num_rows();
		
		if(isset($_SESSION['answer_array'])){

		$arrCount = count($_SESSION['answer_array']);

			if($arrCount > $numQuestions){
				unset($_SESSION['answer_array']);
				$this->load->view("quizMainPage");
			}
			if($arrCount >= $numQuestions){
				
				$this->load->view("enterUser");
			}
		}
		
		$singleSQL = $this->quiz_model->getQuestions($question);

		foreach($singleSQL->result() as $row){
			$id = $row->id;
			$thisQuestion = $row->question;
			$q = '<h2>'.$thisQuestion.'</h2>';
			$sql2 = $this->quiz_model->getAnswers($question);
			foreach($sql2 ->result() as $row2){
				$answer = $row2->answer;
				$correct = $row2->correct;
				$answers .= '<label style="cursor:pointer;"><input type="radio" name="rads" value="'.$correct.'">'.$answer.'</label> 
				<input type="hidden" id="qid" value="'.$id.'" name="qid"><br /><br />
				';
				
			}
			$data['output'] = ''.$q.''.$answers;
			$this->load->view("quiz", $data); 
		   }
			
		
	}
	
		public function handleAnswer(){
			session_start();
			if(isset($_POST['rads']) && $_POST['rads'] != ""){
				$answer = preg_replace('/[^0-9]/', "", $_POST['rads']);
				if(!isset($_SESSION['answer_array']) || count($_SESSION['answer_array']) < 1){
					$_SESSION['answer_array'] = array($answer);
				}else{
					array_push($_SESSION['answer_array'], $answer);
				}
				
			}
			elseif(!isset($_SESSION['answer_array'])){
				$_SESSION['answer_array'] = array(0);
			}
			if(isset($_POST['qid']) && $_POST['qid'] != ""){
				
				$qid = preg_replace('/[^0-9]/', "", $_POST['qid']);
				if(!isset($_SESSION['qid_array']) || count($_SESSION['qid_array']) < 1){

					$_SESSION['qid_array'] = array($qid);
				}else{
					array_push($_SESSION['qid_array'], $qid);
				}
				$_SESSION['lastQuestion'] = $qid;
			}
		
						$countCheck = $this->quiz_model->getAllQuizID();
						$count = $countCheck->num_rows();
						$numCorrect = 0;
						foreach($_SESSION['answer_array'] as $current){
							if($current == 1){
								$numCorrect++;
							}
						}
						$percent = $numCorrect / $count * 100;
						$percent = intval($percent);
					if(isset($_POST['complete']) && $_POST['complete'] == "true"){
						$username = $_POST['username'];
						$username = strip_tags($username);
					if(!in_array("1", $_SESSION['answer_array'])){
						date_default_timezone_set("Europe/Dublin");
						$currentdate = date("Y-m-d h:i");
						$data = array(
							'username' => $username ,
							  'percentage' => $percent ,
							   'date_time' => $currentdate
							);
					$this->quiz_model->insertResult($data);
						$output = "You scored ".$percent."%";
						//echo $output; 
						$data['output'] = $output; 
						
					 	unset($_SESSION['answer_array']);
						unset($_SESSION['qid_array']);
						session_destroy();
						$this->load->view("quizResult", $data);
					}
						else{ 
						
						date_default_timezone_set("Europe/Dublin");
						$currentdate = date("Y-m-d h:i");
						$data = array(
								'username' => $username ,
								  'percentage' => $percent ,
								   'date_time' => $currentdate 
								);
						$this->quiz_model->insertResult($data);
							$output = "Thanks for taking the quiz! You scored ".$percent."%";
							$data['output'] = $output; 
							unset($_SESSION['answer_array']);
							unset($_SESSION['qid_array']);
							session_destroy();
							$this->load->view("quizResult", $data); 
						}
					}
	
			if(isset($_POST['qid'])){	
			$this->getQuestions($_POST['qid'] + 1 );
			}
		}

	
}