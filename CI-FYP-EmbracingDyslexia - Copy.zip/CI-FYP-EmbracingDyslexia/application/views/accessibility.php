<?php
$this->load->view('header'); 
$this->load->helper('url'); 
$base = base_url() . index_page();
$img_base = base_url();
?>




<!--PAGE LOGO & TITLE-->
<!--SECTION 01-->
  <section class="titles">
    <h1>Accessibility Tools That Work For Everyone!</h1>
    <h2>Accessibility Matters!</h2>
      <p>Style an inclusive website that everyone can access & enjoy, no matter what hardware or software they’re using to assist them, websites must be accessible to those with different levels of ability. Check out some helpful links below! </p>
  </section>

<!--SECTION 02-->
  <section class="container-boxes">
    <div class="box">

      <div class="icon">
        <a href=""><i class="fas fa-fire"></i></a>
      </div>

      <div class="text">
        <a href="<?php echo "$base/User/color"?>">
          <h3>Color Safe</h3>
            <p><strong>Color Safe</strong> provides AA & AAA compliant colour suggestions based on your <strong>background colour, font family, font-size,</strong> and <strong>font-weight</strong>. Find out more <a href="<?php echo "$base/User/color"?>">here!</a></p>
        </a>
      </div>

    </div>
      
    <div class="box">

      <div class="icon">
        <a href=""><i class="fas fa-address-card"></i></a>
      </div>

      <div class="text">
          <a href="<?php echo "$base/User/contrast"?>">
          <h3>Colour Contrast Analyser</h3>
            <p>This is a handy <strong>Chrome extension</strong> that can look at any <strong>webpage, image,</strong> or <strong>PDF</strong> open in your browser.</p>
            <p>You can <strong>choose</strong> which part of the screen you’d like to <strong>focus </strong>on: the full page, visible content, or a custom region.<a href="<?php echo "$base/User/contrast"?>">here!</a></p>
        </a>
      </div>

    </div>

    <div class="box">

      <div class="icon">
        <a href=""><i class="fas fa-seedling"></i></a>
      </div>

      <div class="text">
        <a href="<?php echo "$base/User/nocoffee"?>">
            <h3>NoCoffee</h3>
          <p>This <strong>Chrome</strong> extension allows you to see your website as if you had <strong>visual impairments</strong>. It’s a handy tool for seeing your website from another <strong>point of view</strong>. You will <strong>better understand</strong> the difficulties visually impaired visitors have.<a href="<?php echo "$base/User/nocoffee"?>"></a></p>
        </a>
      </div>
    </div>
  </section>




<?php
$this->load->view('footer'); 
?>