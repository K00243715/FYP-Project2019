<?php
$this->load->view('header'); 
$this->load->helper('url'); 
$base = base_url() . index_page();
$img_base = base_url();
?>

<?php
$r = $this->session->userdata('AllResultData');
if(!$r==null){ ?>
	<h1 align="center">Results in Database Table Order</h1>
	<table border="1" align="center">
		<th width="130">Name</th>
        <th width="130">Percentage</th>
        <th width="130">Date/Time</th>
        <?php foreach ($r as $result){
			echo "<tr>";
			    echo "<td width=\"130\">" . $result['username']   . "</td>";
				echo "<td width=\"130\">" . $result['percentage'] . "</td>";
				echo "<td width=\"130\">" . $result['date_time']  . "</td>";
     	    echo "</tr>";
		}?>
    </table>
<?php } ?>

<?php
$r2 = $this->session->userdata('Top3ResultData');
if(!$r2==null){ ?>
	<h1 align="center">Top 3 Results</h1>
	<table border="1" align="center">
		<th width="130">Name</th>
        <th width="130">Percentage</th>
        <th width="130">Date/Time</th>
        <?php foreach ($r2 as $result2){
			echo "<tr>";
			    echo "<td width=\"130\">" . $result2['username']   . "</td>";
				echo "<td width=\"130\">" . $result2['percentage'] . "</td>";
				echo "<td width=\"130\">" . $result2['date_time']  . "</td>";
     	    echo "</tr>";
		}?>
    </table>
<?php } ?>

<?php
$this->load->view('footer'); 
?>