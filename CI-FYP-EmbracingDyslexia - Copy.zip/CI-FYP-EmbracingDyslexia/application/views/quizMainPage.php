<?php
$this->load->view('header'); 
$this->load->helper('url');
$base = base_url() . index_page();
$cssbase = base_url();
$img_base = base_url();



$msg = "";
if(isset($data['msg'])){
	$msg = $_GET['msg'];
	$msg = strip_tags($msg);
	$msg = addslashes($msg);
}
?>


<script>
function startQuiz(url){
	window.location = url;
}
</script>

<!--SECTION 01-->
  <section class="titles">
    <h1>QUIZ TIME</h1>
    <h2>CHALLENGE YOURSELF</h2>
      <p>Return to the Games <a href="<?php echo "$base/User/games"?>">menu</a>?</p>
  </section>

<!--SECTION 02-->
    <section class="container-boxes">
     <div class="box">

      <div class="icon">
        <a href="<?php echo "$base/User/doQuiz"?>"><i class="fas fa-fire"></i></a>
      </div>

      <div class="text">
        <a href="<?php echo "$base/User/doQuiz"?>"><i class="fas fa-fire"></i></a>
            <h3>Click on the image when you are ready to start the quiz</h3>
            <p> <a href="https://codepen.io/katieyang/full/zzWLYv/" target="_blank"></a></p>
    
      </div>
    </div>


    <div class="box">
     
        <?php echo $msg; ?>
        <div class="center-text">
            <a href="<?php echo "$base/Quiz/doQuizStart/1";?>"> Click Here To Begin
            
            <img src="<?php echo $cssbase . "/assets/images/quiz2.png"?>" class="projectsample"></a>
        </div>
        </div>
    </section>



<?php
$this->load->view('footer'); 
?>