<?php
$this->load->helper('url');
$base = base_url() . index_page();
$this->load->view('header'); 
$this->load->helper('url');
?>


<!--SECTION 01-->
  <section class="titles">
    <h1>Register to access more features</h1>
  </section>
<br><br><br><br><br><br><br><br>

<!--SECTION 02-->
  <section class="titles">
    <h2>Fill in the form below</h2>
  </section>

<!--SECTION 03-->
<section class="container-boxes">
    <div class="box">

      <div class="icon">
        <a href=""><i class="fas fa-fire"></i></a>
      </div>

      <div class="text">
        <a href="<?php echo "$base/User/doRegister"?>">
          <h3>Register with us</h3>
            <p>Insert your details in the form to access more features of the website</p>
        </a>
      </div>

    </div>

        <div class="icon">
        <a href="<?php echo "$base/User/accessibility"?>"><i class="fas fa-fire"></i></a>
        </div>  
    
    <div class="sec2innercont">
        <div class="sec2addr">
            <form id="form1" name="form1" method="post" action="<?php echo "$base/User/RegisterUser"; ?>">
        <p>
        <label for="UserName">User Name</label>
        <input type="text" name="UserName" id="UserName" />
        </p>
        <p>
        <label for="Password">Password</label>
        <input type="password" name="Password" id="Password" />
        </p>
        <p>
        <label for="FirstName">First Name</label>
        <input type="text" name="FirstName" id="FirstName" />
        </p>
        <p>
        <label for="Surname">Surname</label>
        <input type="text" name="Surname" id="Surname" />
        </p>
        <p>
        <label for="Mobile">Mobile</label>
        <input type="text" name="Mobile" id="Mobile" />
        </p>
        <p>
        <label for="AddressLine1">Address Line 1</label>
        <input type="text" name="AddressLine1" id="AddressLine1" />
        </p>
        <p>
        <label for="AddressLine2">Address Line 2</label>
        <input type="text" name="AddressLine2" id="AddressLine2" />
        </p>
        <p>
        <label for="AddressLine3">Address Line 3</label>
        <input type="text" name="AddressLine3" id="AddressLine3" />
        </p>
        <p>
        <label for="email">Email</label>
        <input type="text" name="email" id="email" />
        </p>
        <p>
        <input type="submit" name="button" id="button" value="Submit" />
        </p>
            </form> 
        </div>
    </div>
  
</section>

<br><br><br><br><br><br><br><br><br><br><br><br>

<?php
$this->load->view('footer'); 
?>