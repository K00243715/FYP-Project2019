<?php
$this->load->view('header'); 
$this->load->helper('url');
$base = base_url() . index_page();

?>
	<div class="center-text">
	<p>There are no more questions. Please enter your name click finish</p>
	<form action="<?php echo "$base/Quiz/handleAnswer/" ?>" method="post">
	<input type="hidden" name="complete" value="true">
	Name : <input type="text" name="username"></br></br>
	<input type="submit" value="Finish">
	</form>
	</div>
<?php
$this->load->view('footer'); 
?>