<?php
$this->load->view('header'); 
$this->load->helper('url'); 
$base = base_url() . index_page();
$img_base = base_url();
$n = $this->session->userdata('AllNoticeData');
?>


<!--SECTION 01-->
  <section class="titles">
    <h1>'Switching On Accessibility Tools!' </h1>
    <h2>Embracing Dyslexia</h2>
      <p>Bringing together a community to share useful ideas for those with or know somebody with dyslexia!</p>
  </section>

<!--SECTION 02-->
  <section class="container-boxes">
    <div class="box">

      <div class="icon">
        <a href="<?php echo "$base/User/accessibility"?>"><i class="fas fa-fire"></i></a>
      </div>

      <div class="text">
        <a href="<?php echo "$base/User/accessibility"?>">
          <h3>About</h3>
            <p>This website aims to inform users of <strong>accessible tools</strong> that you can adapt for your webpage.<strong>
            <p>Accessibility features</strong> enhances the user experience for all types of users especially for those suffering from <strong>dyslexia</strong>. </p>
        </a>
      </div>
    </div>

    <div class="box">

      <div class="icon">
        <a href=""><i class="fas fa-seedling"></i></a>
      </div>

      <div class="text">
        <a href="">
          <h3>Who is this website for?</h3>
            <p>This website is for <strong>educators, parents and children</strong> who have dyslexia or know somebody who has dyslexia.</p></a>
      </div>

    </div>

    <div class="box">

      <div class="icon">
        <a href=""><i class="fas fa-address-card"></i></a>
      </div>

      <div class="text">
        <a href="<?php echo "$base/User/forum"?>">
          <h3>Have Your Say?</h3>
          <p>It would be great if you could <strong>add</strong> your thoughts on useful ideas  and your experience in the community <strong>forum</strong>. You never know who could benefit!</p>
        </a>
      </div>

    </div>
      
        <div class="box">

      <div class="icon">
        <a href=""><i class="fas fa-fire"></i></a>
      </div>

      <div class="text">
        <a href="<?php echo "$base/User/news"?>">
          <h3>All about Dyslexia</h3>
          <p>Find out about some interesting articles regarding Dyslexia <a href="news.html">here!</a></p>
        </a>
      </div>

    </div>
  </section>


<?php
$this->load->view('footer'); 
?>

