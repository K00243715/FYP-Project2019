<?php
$this->load->helper('url');
$base = base_url() . index_page();
$this->load->view('header'); 
$img_base = base_url();
$cssbase = base_url();
//$user = $this->session->userdata('user');
?>


<!--SECTION 01-->
  <section class="titles">
    <h1>Sign Up or Sign In</h1>
    <h2>It’s free to sign up and access more features. Connect with friends and the community around you on Embracing Dyslexia.</h2>
        </section>
<br>
<br>
<br> 
       
<!--SECTION 02-->
  <section class="container-boxes">
    <div class="box">

      <div class="icon">
      </div>

      <div class="text">
<!--LOGIN-->      
          <h3>Login Here..</h3>
            <form id="form1" name="form1" method="post" action="<?php echo "$base/User/getUser"; ?>">
            <p>
            <label for="username">User Name</label>
            <input type="text" name="UserName" id="username" />
            </p>
            <p>
            <label for="password">Password</label>
            <input type="password" name="password" id="password" />
            </p>
            <p>
            <input type="submit" name="button" id="button" value="Submit" />
            </p>
          </form>
      </div> 
      </div>
      
<!--Make A Profile-->      
      
    <div class="box">
      <div class="icon">
      </div>
      <div class="text">
          <h3>Sign Up Here..</h3>
          <a href="<?php echo "$base/User/doRegister"?>">
          <p><img src="<?php echo $img_base . "assets/images/reg1.png"?>">
          </p>
           </a>  
      </div>
      </div> 
    </section>
 



<?php
$this->load->view('footer'); 
?>