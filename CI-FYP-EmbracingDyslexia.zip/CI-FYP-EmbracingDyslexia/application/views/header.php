<?php 
$this->load->helper('url'); 
$cssbase = base_url();
$img_base = base_url();
$base = base_url() . index_page();
$user = $this->session->userdata('user');
$jsbase = base_url()."assets/js/";
?>



<!DOCTYPE>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <title>FYP - Embracing Dyslexia - K00243715 - Ashley McInerney</title>
    
    <!--reference to CSS file-->
    <link href="<?php echo $cssbase . "/assets/css/styles.css"?>" rel="stylesheet" type="text/css" media="all" />
    
            
    <!--tab favicon-->
    <link href="$user = $this->session->userdata('user');fav2.PNG"?>
        
    <!--W3Schools Search Icon Info-->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    
    
    <meta name="description" content="" />
	<link href="http://fonts.googleapis.com/css?family=Source+Sans+Pro:200,300,400,600,700" rel="stylesheet" type="text/css" />
	<link href="<?php echo $cssbase . "assets/css/gallery.css"?>" rel="stylesheet" type="text/css" media="all" />
	<link href="<?php echo $cssbase . "assets/css/jsquizstyle.css"?>" rel="stylesheet" type="text/css" media="all" />
    
	<script src="<?php echo $jsbase."jsquizscript.js"?>"></script>
</head>
    
    
    
<!--BODY-->
<body>

<!--HEADER--> 
  <header>
      
    <div>
        <a href="<?php echo "$base/User/User"?>">   
        <img src="<?php echo $img_base . "assets/images/logo3.PNG"?>" alt="logoFavicon">
        <link rel="icon"></a>
        
      <i class="fas fa-atom"></i>
    </div>
      
<!--NAV BAR-->    
    <nav>
      <ul>
	  <?php if ($user['UserID'] > 0) {?>
				<li><a href="<?php echo "$base/User/User"?>">Home</a></li>

				<li><a href="<?php echo "$base/User/accessibility"?>">Accessibility</a></li>
				<li><a href="<?php echo "$base/NewController/doJSQuiz";?>">Quiz (JS) </a></li>
				<li><a href="<?php echo "$base/NewController/doResults";?>">Results </a></li>
				<li><a href="<?php echo "$base/User/games"?>">Games</a></li>
          
				<li><a href="<?php echo "$base/User/forum"?>">Forum</a></li>
          
	           <li><a href="<?php echo "$base/User/logout/"?>">Log out</a></li>
				
				
			<?php } else { ?>
				<li><a href="<?php echo "$base/User/User"?>">Home</a></li>
				
				<li><a href="<?php echo "$base/User/doRegister"; ?>">Register</a></li>
          
                <li><a href="<?php echo "$base/User/dologon"; ?>">Login</a></li>
          
                <li><a href="<?php echo "$base/User/contact"?>">Contact</a></li>
			<?php } ?>
    

      </ul>
        
        
        
    </nav>
      
  </header>
    
	<p>&nbsp;</p>
    
    