<?php
$this->load->view('header'); 
$this->load->helper('url');
$base = base_url() . index_page();
$cssbase = base_url();
?>

<form id="form1" name="form1" method="post" action="<?php echo "$base/Quiz/handleAnswer/" ?>">
<?php echo $output ?>
    
<input type="submit" name="button" id="button" value="Submit" />
</form>

<?php
$this->load->view('footer'); 
?>