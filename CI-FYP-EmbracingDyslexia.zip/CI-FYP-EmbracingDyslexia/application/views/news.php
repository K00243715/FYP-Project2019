<?php
$this->load->view('header'); 
$this->load->helper('url'); 
$base = base_url() . index_page();
$img_base = base_url();
?>




<!--COLUMNS-->
<div class="content">
    <div class="collumns">
        
<!--COLUMN 01-->
        <div class="collumn">
            <div class="head"><span class="headline hl3">What is Dyslexia?</span><p><span class="headline hl4"> understood.org</span></p></div>
            <p><strong>Dyslexia</strong> is a specific learning disability in reading. Kids with dyslexia have trouble reading accurately and fluently. They may also have trouble with reading comprehension, spelling and writing.</p>
            
            <p>Dyslexia is a lifelong condition and it’s the most common learning issue, although it’s not clear what percentage of kids have it.</p>
            <p>Some experts believe the number is between 5 and 10 percent. Others say as many as 17 percent of people show signs of reading issues. The reason for the wide range is that experts may define dyslexia in different ways.</p>
            
            <figure class="figure">
								<img class="media" src="https://media.giphy.com/media/oz62hY2Yu60OQ/giphy.gif" alt="">
								<figcaption class="figcaption">My mind hops over words!</figcaption>
						</figure>
            
            <p>Kids with dyslexia may have trouble answering questions about something they’ve read. But when it’s read to them, they may have no difficulty at all.</p>
            
            <p>People sometimes believe dyslexia is a visual issue. They think of it as kids reversing letters or writing backwards. But dyslexia is not a problem with vision or with seeing letters in the wrong direction.</p>
            
            <p>It’s important to know that while dyslexia impacts learning, it’s not a problem of intelligence. Kids with this issue are just as smart as their peers. Many people have struggled with dyslexia and gone on to have successful careers. That includes a long list of actors, entrepreneurs and elected officials.</p>
            
            <p>If your child has dyslexia, she won’t outgrow it. But there are supports, teaching approaches and strategies to help her overcome her challenges.</p>
        </div>
        
<!--COLUMN 02-->
        <div class="collumn">
            <div class="head"><span class="headline hl5">See Dyslexia Through A Childs EYES?</span><p><span class="headline hl6">Experience the simulation<a href="https://www.understood.org/en/tools/through-your-childs-eyes"> here!</a></span></p></div>
            <p>It’s one thing to read about learning and attention issues. It’s another thing to see them through your child’s eyes. Experience firsthand how frustrating it is when your hand won’t write what your brain is telling it to. Or how hard it is to complete a simple task when you have trouble focusing. Use these unique simulations and videos to better understand your child’s world.</p>
            
             <span class="citation">"You have magical brains, they just process differently. Don’t feel like you should be held back by it."</span>
           
            <p>Tailor the simulation, expert advice and child’s story by selecting your child’s issue(s) and grade level—or select a child from your profile.</p>
            </div>
     
        
<!--COLUMN 03-->     
        <div class="collumn"><div class="head"><span class="headline hl1">Dyslexia in Adults</span>     <p><span class="headline hl2">Adult Dyslexia Checklist</span></p></div>
            <figure class="figure">
				<img class="media" src="https://media.giphy.com/media/oNw2xEiUlHJdLP3cGb/giphy.gif" alt="">
				<figcaption class="figcaption">"
                    Stay Positive!</figcaption>
            </figure>        
            <p>Each person with dyslexia has a unique profile of strengths and weaknesses.  Indicators of dyslexia differ at different ages and depending on the environment, e.g. college or the workplace.  The following check list may help to identify signs of a dyslexic difficulty.</p>
            <p>A psycho-educational assessment will be required to make a diagnosis.  The check list may help to confirm the suspicions that there is a difficulty present and therefore help in making the decision to obtain an assessment.</p>
            </div>

<!--COLUMN 04-->
            <div class="collumn"><div class="head"><span class="headline hl3">Why Web Accessibility Is Important </span><p><span class="headline hl4">And How You Can Accomplish It</span></p></div>

            <p>“Accessibility means the ability of everyone regardless of their condition to have access to something (e.g internet, transport system).”</p>

            <p>So we could eventually say the Web Accessibility is a way to make everyone including the disabled to have access to the web and internet in whole.</p>
            <span class="citation">"“ Accessibility refers to the design of products, devices, services, or environments for people who experience disabilities.”"</span>

            <p>The Web and Internet in whole is an increasingly important resource in many aspects of our life which includes: education, employment, government, commerce, health care, recreation, and more.</p>
            <p>It is important that the Web be accessible to everyone in order to provide equal access and equal opportunity to people with disabilities. An accessible Web can help people with disabilities participate more actively in society.</p> 
            <figure class="figure">
                <img class="media" src="https://media.giphy.com/media/27ICYnyMyW9eE/giphy.gif" alt="">
                <figcaption class="figcaption">"What its like to read with dyslexia!"
                </figcaption></figure>
            
            <p>An accessible website gives the access to information and interaction for many people with disabilities. That is, the accessibility barriers to print, audio, and visual media can be much more easily overcome through Web technologies.</p>
                </div>
    </div>
    </div>




<?php
$this->load->view('footer'); 
?>