<?php
$this->load->view('header'); 
$this->load->helper('url'); 
$base = base_url() . index_page();
$img_base = base_url();
$cssbase = base_url();
$user = $this->session->userdata('user');
if ($user['UserID'] > 0) {
    
}
else{
    redirect("$base/User/dologon", 'refresh');
}
?>




<!--PAGE LOGO & TITLE-->
<!--SECTION 01-->
  <section class="titles">
    <h1>Have Your Say!</h1>
    <h2>Leave your advice & experience in the community forum. </h2>
    <p>Your never know who will benefit!</p>
  </section>
       
       
<!--SECTION 02-->
  <section class="container-boxes">
    <div class="box">

      <div class="icon">
        <a href=""><i class="fas fa-fire"></i></a>
      </div>

      <div class="text">
        <a href="">
          <h3>Community Forum</h3>
            <p>Access the forum by pressing the image on the right!</p>
            <p>Add your valuable information so that others may benefit!</p>
        </a>
      </div> 
      </div>
      
         <div class="box">

      <div class="icon">
        <a href="<?php echo "$base/User/disqus"?>"><i class="fas fa-fire"></i></a>
      </div>

      <div class="text">
        <a href="<?php echo "$base/User/disqus"?>">
            <h3>Press The Image</h3>
            <p><img src="<?php echo $img_base . "assets/images/FORUM.PNG"?>"></p>
        </a>
      </div>

    </div>
       </section>


<?php
$this->load->view('footer'); 
?>