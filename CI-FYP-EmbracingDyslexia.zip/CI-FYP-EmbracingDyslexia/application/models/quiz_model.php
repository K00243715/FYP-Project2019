<?php

class quiz_model extends CI_Model {

	public function __construct(){
		parent::__construct();
		$this->load->database();
	}

	public function getAllQuizID(){

		return $this->db->query("SELECT id FROM questions");
	}
	
	public function getQuestions($q1){

		return $this->db->query("SELECT * FROM questions WHERE id='$q1'");
	}
	
	public function getAnswers($q2){

		return $this->db->query("SELECT * FROM answers WHERE question_id='$q2' ORDER BY rand()");
	}

	public function insertResult($data){
		$this->db->insert('quiz_takers',$data);

	}
	public function getAllResults(){
		$query = $this->db->get('quiz_takers');
		return $query->result_array();
	}

	public function getTop3Results(){
		$this->db->order_by("percentage", "desc"); 
		$query = $this->db->get('quiz_takers', 3);
		return $query->result_array();
	}


}
?>