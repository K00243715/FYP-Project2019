<?php 

class NewController extends CI_Controller {

	public function __construct(){
		parent::__construct();
		$this->load->model('User_Model');
		$this->load->library('session');
		$this->load->model('Notice_Model');
		$this->load->model('quiz_model');
	}

	public function index() {
	}
	
	public function doGallery(){
		$this->load->view("gallery");
	}

	public function doAbout(){
		$this->load->view("about");
	}
	
	public function doJSQuiz(){
		$this->load->view("jsquiz");
	}

	public function doResults(){
		//capture an array of all results
		$data["AllResults"] = $this->quiz_model->getAllResults();
		$resultData = array('AllResultData'  => $data["AllResults"]);
		$this->session->set_userdata($resultData);
		
		//capture an array of top 3 results
		$data["Top3Results"] = $this->quiz_model->getTop3Results();
		$resultDataTop3 = array('Top3ResultData'  => $data["Top3Results"]);
		$this->session->set_userdata($resultDataTop3);	
		
		$this->load->view("results");
	}

	public function doResponsive(){
		$this->load->view("responsive");
	}

	public function doDisqus(){
		$this->load->view("disqus");
	}
	
	public function doFlash(){
		$this->load->view("flash");
	}

	public function doQuiz(){
		session_start();
		if(isset($_SESSION['answer_array']) || isset($_SESSION['qid_array'])){
		unset($_SESSION['answer_array']);
		unset($_SESSION['qid_array']);
		}
		$this->load->view("quizMainPage");
	}
}