-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 09, 2019 at 07:14 PM
-- Server version: 10.1.36-MariaDB
-- PHP Version: 7.2.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ciplus2019`
--

-- --------------------------------------------------------

--
-- Table structure for table `answers`
--

CREATE TABLE `answers` (
  `id` int(11) NOT NULL,
  `question_id` int(11) NOT NULL,
  `answer` varchar(255) NOT NULL,
  `correct` enum('0','1') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `answers`
--

INSERT INTO `answers` (`id`, `question_id`, `answer`, `correct`) VALUES
(1, 1, 'Dublin', '1'),
(2, 1, 'London', '0'),
(3, 1, 'Paris', '0'),
(4, 1, 'Washington D.C.', '0'),
(5, 2, 'Washington D.C.', '1'),
(6, 2, 'Paris', '0'),
(7, 2, 'Dublin', '0'),
(8, 2, 'New York', '0'),
(9, 3, 'London', '1'),
(10, 3, 'Paris', '0'),
(11, 3, 'Dublin', '0'),
(12, 3, 'Berlin', '0');

-- --------------------------------------------------------

--
-- Table structure for table `ci_sessions`
--

CREATE TABLE `ci_sessions` (
  `session_id` varchar(40) NOT NULL DEFAULT '0',
  `ip_address` varchar(45) NOT NULL DEFAULT '0',
  `user_agent` varchar(120) NOT NULL,
  `last_activity` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `user_data` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ci_sessions`
--

INSERT INTO `ci_sessions` (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES
('7834f756ae9748c10e411098e51aaffc', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.86 Safari/537.36', 1554823887, 'a:4:{s:9:\"user_data\";s:0:\"\";s:13:\"AllNoticeData\";a:4:{i:0;a:9:{s:8:\"noticeId\";s:1:\"1\";s:6:\"userId\";s:1:\"1\";s:16:\"shortDescription\";s:13:\"logs for sale\";s:15:\"longDescription\";s:37:\"hard wood and soft wood logs for sale\";s:10:\"largeImage\";s:8:\"logs.jpg\";s:10:\"smallImage\";s:8:\"logs.jpg\";s:4:\"area\";s:8:\"Limerick\";s:12:\"dateUploaded\";s:10:\"2014-03-19\";s:7:\"dateExp\";s:10:\"2014-04-30\";}i:1;a:9:{s:8:\"noticeId\";s:1:\"2\";s:6:\"userId\";s:1:\"1\";s:16:\"shortDescription\";s:11:\"art classes\";s:15:\"longDescription\";s:33:\"all types available for birthdays\";s:10:\"largeImage\";s:7:\"art.jpg\";s:10:\"smallImage\";s:7:\"art.jpg\";s:4:\"area\";s:8:\"Limerick\";s:12:\"dateUploaded\";s:10:\"2014-03-18\";s:7:\"dateExp\";s:10:\"2014-03-25\";}i:2;a:9:{s:8:\"noticeId\";s:1:\"3\";s:6:\"userId\";s:1:\"3\";s:16:\"shortDescription\";s:4:\"fish\";s:15:\"longDescription\";s:19:\"a fishy description\";s:10:\"largeImage\";s:8:\"fish.jpg\";s:10:\"smallImage\";s:8:\"fish.jpg\";s:4:\"area\";s:8:\"limerick\";s:12:\"dateUploaded\";s:10:\"2014-03-25\";s:7:\"dateExp\";s:10:\"2014-03-26\";}i:3;a:9:{s:8:\"noticeId\";s:1:\"4\";s:6:\"userId\";s:1:\"1\";s:16:\"shortDescription\";s:7:\"Lessons\";s:15:\"longDescription\";s:20:\"Horse Riding Lessons\";s:10:\"largeImage\";s:9:\"horse.jpg\";s:10:\"smallImage\";s:0:\"\";s:4:\"area\";s:8:\"Limerick\";s:12:\"dateUploaded\";s:10:\"0000-00-00\";s:7:\"dateExp\";s:10:\"0000-00-00\";}}s:4:\"user\";a:10:{s:6:\"UserID\";s:1:\"1\";s:8:\"UserName\";s:4:\"lisa\";s:8:\"Password\";s:32:\"e9803a706f81a40884b8aeafafb2cfd3\";s:9:\"FirstName\";s:4:\"Lisa\";s:7:\"SurName\";s:6:\"Bailey\";s:6:\"Mobile\";s:9:\"556565656\";s:12:\"AddressLine1\";s:3:\"LIT\";s:12:\"AddressLine2\";s:7:\"Moylish\";s:12:\"AddressLine3\";s:8:\"Limerick\";s:5:\"Email\";s:11:\"lisa@lit.ie\";}s:10:\"noticeData\";a:3:{i:0;a:9:{s:8:\"noticeId\";s:1:\"1\";s:6:\"userId\";s:1:\"1\";s:16:\"shortDescription\";s:13:\"logs for sale\";s:15:\"longDescription\";s:37:\"hard wood and soft wood logs for sale\";s:10:\"largeImage\";s:8:\"logs.jpg\";s:10:\"smallImage\";s:8:\"logs.jpg\";s:4:\"area\";s:8:\"Limerick\";s:12:\"dateUploaded\";s:10:\"2014-03-19\";s:7:\"dateExp\";s:10:\"2014-04-30\";}i:1;a:9:{s:8:\"noticeId\";s:1:\"2\";s:6:\"userId\";s:1:\"1\";s:16:\"shortDescription\";s:11:\"art classes\";s:15:\"longDescription\";s:33:\"all types available for birthdays\";s:10:\"largeImage\";s:7:\"art.jpg\";s:10:\"smallImage\";s:7:\"art.jpg\";s:4:\"area\";s:8:\"Limerick\";s:12:\"dateUploaded\";s:10:\"2014-03-18\";s:7:\"dateExp\";s:10:\"2014-03-25\";}i:2;a:9:{s:8:\"noticeId\";s:1:\"4\";s:6:\"userId\";s:1:\"1\";s:16:\"shortDescription\";s:7:\"Lessons\";s:15:\"longDescription\";s:20:\"Horse Riding Lessons\";s:10:\"largeImage\";s:9:\"horse.jpg\";s:10:\"smallImage\";s:0:\"\";s:4:\"area\";s:8:\"Limerick\";s:12:\"dateUploaded\";s:10:\"0000-00-00\";s:7:\"dateExp\";s:10:\"0000-00-00\";}}}'),
('494200464fb5abc3caf121cff3367637', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.86 Safari/537.36', 1554823897, 'a:2:{s:9:\"user_data\";s:0:\"\";s:13:\"AllNoticeData\";a:4:{i:0;a:9:{s:8:\"noticeId\";s:1:\"1\";s:6:\"userId\";s:1:\"1\";s:16:\"shortDescription\";s:13:\"logs for sale\";s:15:\"longDescription\";s:37:\"hard wood and soft wood logs for sale\";s:10:\"largeImage\";s:8:\"logs.jpg\";s:10:\"smallImage\";s:8:\"logs.jpg\";s:4:\"area\";s:8:\"Limerick\";s:12:\"dateUploaded\";s:10:\"2014-03-19\";s:7:\"dateExp\";s:10:\"2014-04-30\";}i:1;a:9:{s:8:\"noticeId\";s:1:\"2\";s:6:\"userId\";s:1:\"1\";s:16:\"shortDescription\";s:11:\"art classes\";s:15:\"longDescription\";s:33:\"all types available for birthdays\";s:10:\"largeImage\";s:7:\"art.jpg\";s:10:\"smallImage\";s:7:\"art.jpg\";s:4:\"area\";s:8:\"Limerick\";s:12:\"dateUploaded\";s:10:\"2014-03-18\";s:7:\"dateExp\";s:10:\"2014-03-25\";}i:2;a:9:{s:8:\"noticeId\";s:1:\"3\";s:6:\"userId\";s:1:\"3\";s:16:\"shortDescription\";s:4:\"fish\";s:15:\"longDescription\";s:19:\"a fishy description\";s:10:\"largeImage\";s:8:\"fish.jpg\";s:10:\"smallImage\";s:8:\"fish.jpg\";s:4:\"area\";s:8:\"limerick\";s:12:\"dateUploaded\";s:10:\"2014-03-25\";s:7:\"dateExp\";s:10:\"2014-03-26\";}i:3;a:9:{s:8:\"noticeId\";s:1:\"4\";s:6:\"userId\";s:1:\"1\";s:16:\"shortDescription\";s:7:\"Lessons\";s:15:\"longDescription\";s:20:\"Horse Riding Lessons\";s:10:\"largeImage\";s:9:\"horse.jpg\";s:10:\"smallImage\";s:0:\"\";s:4:\"area\";s:8:\"Limerick\";s:12:\"dateUploaded\";s:10:\"0000-00-00\";s:7:\"dateExp\";s:10:\"0000-00-00\";}}}'),
('645e8a56ff5f22ad539a00850a74dea5', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.86 Safari/537.36', 1554824190, 'a:2:{s:9:\"user_data\";s:0:\"\";s:13:\"AllNoticeData\";a:4:{i:0;a:9:{s:8:\"noticeId\";s:1:\"1\";s:6:\"userId\";s:1:\"1\";s:16:\"shortDescription\";s:13:\"logs for sale\";s:15:\"longDescription\";s:37:\"hard wood and soft wood logs for sale\";s:10:\"largeImage\";s:8:\"logs.jpg\";s:10:\"smallImage\";s:8:\"logs.jpg\";s:4:\"area\";s:8:\"Limerick\";s:12:\"dateUploaded\";s:10:\"2014-03-19\";s:7:\"dateExp\";s:10:\"2014-04-30\";}i:1;a:9:{s:8:\"noticeId\";s:1:\"2\";s:6:\"userId\";s:1:\"1\";s:16:\"shortDescription\";s:11:\"art classes\";s:15:\"longDescription\";s:33:\"all types available for birthdays\";s:10:\"largeImage\";s:7:\"art.jpg\";s:10:\"smallImage\";s:7:\"art.jpg\";s:4:\"area\";s:8:\"Limerick\";s:12:\"dateUploaded\";s:10:\"2014-03-18\";s:7:\"dateExp\";s:10:\"2014-03-25\";}i:2;a:9:{s:8:\"noticeId\";s:1:\"3\";s:6:\"userId\";s:1:\"3\";s:16:\"shortDescription\";s:4:\"fish\";s:15:\"longDescription\";s:19:\"a fishy description\";s:10:\"largeImage\";s:8:\"fish.jpg\";s:10:\"smallImage\";s:8:\"fish.jpg\";s:4:\"area\";s:8:\"limerick\";s:12:\"dateUploaded\";s:10:\"2014-03-25\";s:7:\"dateExp\";s:10:\"2014-03-26\";}i:3;a:9:{s:8:\"noticeId\";s:1:\"4\";s:6:\"userId\";s:1:\"1\";s:16:\"shortDescription\";s:7:\"Lessons\";s:15:\"longDescription\";s:20:\"Horse Riding Lessons\";s:10:\"largeImage\";s:9:\"horse.jpg\";s:10:\"smallImage\";s:0:\"\";s:4:\"area\";s:8:\"Limerick\";s:12:\"dateUploaded\";s:10:\"0000-00-00\";s:7:\"dateExp\";s:10:\"0000-00-00\";}}}'),
('b682afa5e82207d45a40c221074988a2', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.86 Safari/537.36', 1554824441, 'a:2:{s:9:\"user_data\";s:0:\"\";s:13:\"AllNoticeData\";a:4:{i:0;a:9:{s:8:\"noticeId\";s:1:\"1\";s:6:\"userId\";s:1:\"1\";s:16:\"shortDescription\";s:13:\"logs for sale\";s:15:\"longDescription\";s:37:\"hard wood and soft wood logs for sale\";s:10:\"largeImage\";s:8:\"logs.jpg\";s:10:\"smallImage\";s:8:\"logs.jpg\";s:4:\"area\";s:8:\"Limerick\";s:12:\"dateUploaded\";s:10:\"2014-03-19\";s:7:\"dateExp\";s:10:\"2014-04-30\";}i:1;a:9:{s:8:\"noticeId\";s:1:\"2\";s:6:\"userId\";s:1:\"1\";s:16:\"shortDescription\";s:11:\"art classes\";s:15:\"longDescription\";s:33:\"all types available for birthdays\";s:10:\"largeImage\";s:7:\"art.jpg\";s:10:\"smallImage\";s:7:\"art.jpg\";s:4:\"area\";s:8:\"Limerick\";s:12:\"dateUploaded\";s:10:\"2014-03-18\";s:7:\"dateExp\";s:10:\"2014-03-25\";}i:2;a:9:{s:8:\"noticeId\";s:1:\"3\";s:6:\"userId\";s:1:\"3\";s:16:\"shortDescription\";s:4:\"fish\";s:15:\"longDescription\";s:19:\"a fishy description\";s:10:\"largeImage\";s:8:\"fish.jpg\";s:10:\"smallImage\";s:8:\"fish.jpg\";s:4:\"area\";s:8:\"limerick\";s:12:\"dateUploaded\";s:10:\"2014-03-25\";s:7:\"dateExp\";s:10:\"2014-03-26\";}i:3;a:9:{s:8:\"noticeId\";s:1:\"4\";s:6:\"userId\";s:1:\"1\";s:16:\"shortDescription\";s:7:\"Lessons\";s:15:\"longDescription\";s:20:\"Horse Riding Lessons\";s:10:\"largeImage\";s:9:\"horse.jpg\";s:10:\"smallImage\";s:0:\"\";s:4:\"area\";s:8:\"Limerick\";s:12:\"dateUploaded\";s:10:\"0000-00-00\";s:7:\"dateExp\";s:10:\"0000-00-00\";}}}'),
('7628520e664d31287e043b052de347db', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.86 Safari/537.36', 1554829684, ''),
('1c5d6ad17258ffd84bbc141fbd9f4ce5', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.86 Safari/537.36', 1554829785, 'a:2:{s:9:\"user_data\";s:0:\"\";s:13:\"AllNoticeData\";a:4:{i:0;a:9:{s:8:\"noticeId\";s:1:\"1\";s:6:\"userId\";s:1:\"1\";s:16:\"shortDescription\";s:13:\"logs for sale\";s:15:\"longDescription\";s:37:\"hard wood and soft wood logs for sale\";s:10:\"largeImage\";s:8:\"logs.jpg\";s:10:\"smallImage\";s:8:\"logs.jpg\";s:4:\"area\";s:8:\"Limerick\";s:12:\"dateUploaded\";s:10:\"2014-03-19\";s:7:\"dateExp\";s:10:\"2014-04-30\";}i:1;a:9:{s:8:\"noticeId\";s:1:\"2\";s:6:\"userId\";s:1:\"1\";s:16:\"shortDescription\";s:11:\"art classes\";s:15:\"longDescription\";s:33:\"all types available for birthdays\";s:10:\"largeImage\";s:7:\"art.jpg\";s:10:\"smallImage\";s:7:\"art.jpg\";s:4:\"area\";s:8:\"Limerick\";s:12:\"dateUploaded\";s:10:\"2014-03-18\";s:7:\"dateExp\";s:10:\"2014-03-25\";}i:2;a:9:{s:8:\"noticeId\";s:1:\"3\";s:6:\"userId\";s:1:\"3\";s:16:\"shortDescription\";s:4:\"fish\";s:15:\"longDescription\";s:19:\"a fishy description\";s:10:\"largeImage\";s:8:\"fish.jpg\";s:10:\"smallImage\";s:8:\"fish.jpg\";s:4:\"area\";s:8:\"limerick\";s:12:\"dateUploaded\";s:10:\"2014-03-25\";s:7:\"dateExp\";s:10:\"2014-03-26\";}i:3;a:9:{s:8:\"noticeId\";s:1:\"4\";s:6:\"userId\";s:1:\"1\";s:16:\"shortDescription\";s:7:\"Lessons\";s:15:\"longDescription\";s:20:\"Horse Riding Lessons\";s:10:\"largeImage\";s:9:\"horse.jpg\";s:10:\"smallImage\";s:0:\"\";s:4:\"area\";s:8:\"Limerick\";s:12:\"dateUploaded\";s:10:\"0000-00-00\";s:7:\"dateExp\";s:10:\"0000-00-00\";}}}');

-- --------------------------------------------------------

--
-- Table structure for table `notice`
--

CREATE TABLE `notice` (
  `noticeId` int(11) NOT NULL,
  `userId` int(11) NOT NULL,
  `shortDescription` varchar(50) NOT NULL,
  `longDescription` varchar(250) NOT NULL,
  `largeImage` varchar(50) NOT NULL,
  `smallImage` varchar(50) NOT NULL,
  `area` varchar(50) NOT NULL,
  `dateUploaded` date NOT NULL,
  `dateExp` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `notice`
--

INSERT INTO `notice` (`noticeId`, `userId`, `shortDescription`, `longDescription`, `largeImage`, `smallImage`, `area`, `dateUploaded`, `dateExp`) VALUES
(1, 1, 'logs for sale', 'hard wood and soft wood logs for sale', 'logs.jpg', 'logs.jpg', 'Limerick', '2014-03-19', '2014-04-30'),
(2, 1, 'art classes', 'all types available for birthdays', 'art.jpg', 'art.jpg', 'Limerick', '2014-03-18', '2014-03-25'),
(3, 3, 'fish', 'a fishy description', 'fish.jpg', 'fish.jpg', 'limerick', '2014-03-25', '2014-03-26'),
(4, 1, 'Lessons', 'Horse Riding Lessons', 'horse.jpg', '', 'Limerick', '0000-00-00', '0000-00-00');

-- --------------------------------------------------------

--
-- Table structure for table `questions`
--

CREATE TABLE `questions` (
  `id` int(11) NOT NULL,
  `question_id` int(11) NOT NULL,
  `question` varchar(255) NOT NULL,
  `type` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `questions`
--

INSERT INTO `questions` (`id`, `question_id`, `question`, `type`) VALUES
(1, 1, 'Capital of Ireland', 'mc'),
(2, 2, 'Capital of America', 'mc'),
(3, 3, 'Capital of England', 'mc');

-- --------------------------------------------------------

--
-- Table structure for table `quiz_takers`
--

CREATE TABLE `quiz_takers` (
  `id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `percentage` varchar(24) NOT NULL,
  `date_time` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `quiz_takers`
--

INSERT INTO `quiz_takers` (`id`, `username`, `percentage`, `date_time`) VALUES
(20, 'sharon', '66', '2019-03-26 07:54:00'),
(21, 'Joe ', '33', '2019-03-26 07:59:00'),
(22, 'Susan', '100', '2019-03-26 08:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `UserID` int(11) NOT NULL,
  `UserName` varchar(50) NOT NULL,
  `Password` varchar(50) NOT NULL,
  `FirstName` varchar(50) NOT NULL,
  `SurName` varchar(50) NOT NULL,
  `Mobile` varchar(50) NOT NULL,
  `AddressLine1` varchar(50) NOT NULL,
  `AddressLine2` varchar(50) NOT NULL,
  `AddressLine3` varchar(50) NOT NULL,
  `Email` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`UserID`, `UserName`, `Password`, `FirstName`, `SurName`, `Mobile`, `AddressLine1`, `AddressLine2`, `AddressLine3`, `Email`) VALUES
(1, 'lisa', 'e9803a706f81a40884b8aeafafb2cfd3', 'Lisa', 'Bailey', '556565656', 'LIT', 'Moylish', 'Limerick', 'lisa@lit.ie'),
(2, 'Mike', '4c3e1ec04215f69d6a8e9c023c9e4572', 'Mike', 'Ryan', '88888888888', 'Main Street', 'Dublin Road', 'Limerick', 'gh@lit.ie'),
(3, 'john', '6e0b7076126a29d5dfcbd54835387b7b', 'John', 'Ryan', '454545454', 'some where', 'some address', 'some town', 'email@lit.ie');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `answers`
--
ALTER TABLE `answers`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `notice`
--
ALTER TABLE `notice`
  ADD PRIMARY KEY (`noticeId`),
  ADD KEY `userId` (`userId`);

--
-- Indexes for table `questions`
--
ALTER TABLE `questions`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `quiz_takers`
--
ALTER TABLE `quiz_takers`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`UserID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `answers`
--
ALTER TABLE `answers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `notice`
--
ALTER TABLE `notice`
  MODIFY `noticeId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `questions`
--
ALTER TABLE `questions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `quiz_takers`
--
ALTER TABLE `quiz_takers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `UserID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `notice`
--
ALTER TABLE `notice`
  ADD CONSTRAINT `notice_ibfk_1` FOREIGN KEY (`userId`) REFERENCES `user` (`UserID`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;